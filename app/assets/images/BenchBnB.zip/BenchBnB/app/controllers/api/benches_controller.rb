class Api::BenchesController < ApplicationController
    def create
        
    end

    def index
        
    end

    def show
        
    end
    
end
